<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	
	<h1>Welcome Home, {{session('email')}}</h1> ||
	<a href="/system/category">Category List</a>||
	<a href="/system/tag">Tag List</a>||
	<a href="/logout">Logout</a>
</body>
</html>