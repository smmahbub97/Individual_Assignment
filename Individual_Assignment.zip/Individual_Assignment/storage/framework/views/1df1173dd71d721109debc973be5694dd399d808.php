<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
</head>
<body>
	<form method="post" >
		<?php echo csrf_field(); ?>
		Name: <input type="text" name="name" > <br>
		Email: <input type="email" name="email" > <br>
		Password: <input type="password" name="password" ><br>
		Repeat Password: <input type="password" name="password_confirmation" > <br>
		Role: <input type="text" name="role" > <br>
		<input type="submit" name="submit" value="Submit" >
		<a href="/system/supportstaff/login">Back</a>

	</form>

	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo e($err); ?> <br>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH C:\Users\Shishir\Downloads\atpASS\Individual_Assignment\resources\views//register/index.blade.php ENDPATH**/ ?>