<!DOCTYPE html>
<html>
<head>
	
</head>
<body>	
	<h1>Category List</h1>&nbsp
	<a href="/system/user/home">Back</a>| 
	<a href="/logout">Logout</a>

	<table border="1">
		<tr>
			<th>Category ID</th>
			<th>Category Name</th>
			<th>Tag</th>
			<th>Action</th>
		</tr>
		
		<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($category->catid); ?></td>
			<td><?php echo e($category->catname); ?></td>
			<td><?php echo e($category->tag); ?></td>
			<td>
				<a href="<?php echo e(route('user.editcategory',$category->catid)); ?>">Edit</a> ||
				<a href="<?php echo e(route('user.deletecategory',$category->catid)); ?>">Delete</a>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>

</body>
</html><?php /**PATH C:\Users\Shishir\Downloads\atpASS\Individual_Assignment\resources\views/user/view_category.blade.php ENDPATH**/ ?>