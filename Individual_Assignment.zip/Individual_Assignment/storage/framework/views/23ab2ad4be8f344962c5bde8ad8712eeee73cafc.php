<!DOCTYPE html>
<html>
<head>
</head>
<body>	
 	| 
	<a href="/system/admin/home">Back</a>| 
	<a href="/system/supportstaff/add">Add New</a>|
	<a href="/logout">Logout</a>

	<table border="1">
		<tr>
			<th>ID</th>
			<th>Name</th>
			<th>Email</th>
			<th>Company</th>
			<th>Registered</th>
			<th>ACTION</th>
		</tr>
		
		<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($user->id); ?></td>
			<td><?php echo e($user->name); ?></td>
			<td><?php echo e($user->email); ?></td>
			<td><?php echo e($user->company); ?></td>
			<td><?php echo e($user->registered); ?></td>
			<td>
				<a href="#">Edit</a> | 
				<a href="<?php echo e(route('admin.deletemanager',$user->id)); ?>">Delete</a>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>

</body>
</html><?php /**PATH D:\ATP-03\DEMO\resources\views/admin/view_all_staff.blade.php ENDPATH**/ ?>