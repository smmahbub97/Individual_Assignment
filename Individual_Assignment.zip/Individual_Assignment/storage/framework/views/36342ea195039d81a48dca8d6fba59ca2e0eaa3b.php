<!DOCTYPE html>
<html>
<head>
	
</head>
<body>	
	<h1>List of Tag</h1>&nbsp
	<a href="/system/tag/add">Add Tag</a>||
	<a href="/system/user/home">Back</a>| 
	<a href="/logout">Logout</a>

	<table border="1">
		<tr>
			<th>Tag ID</th>
			<th>Tag</th>
			<th>Action</th>
		</tr>
		
		<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($tag->tagid); ?></td>
			<td><?php echo e($tag->hashtag); ?></td>
			<td>
				<a href="<?php echo e(route('user.edittag',$tag->tagid)); ?>">Edit</a> ||
				<a href="<?php echo e(route('user.deletetag',$tag->tagid)); ?>">Delete</a>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>

</body>
</html><?php /**PATH C:\Users\Shishir\Downloads\atpASS\Individual_Assignment\resources\views/user/view_tag.blade.php ENDPATH**/ ?>