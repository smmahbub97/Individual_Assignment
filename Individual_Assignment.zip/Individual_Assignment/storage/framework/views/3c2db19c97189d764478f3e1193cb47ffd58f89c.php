<!DOCTYPE html>
<html>
<head>
	<title>Add Page</title>
</head>
<body>
	<form method="post" >
		<?php echo csrf_field(); ?>
		Name: <input type="text" name="name" > <br>
		Location: <input type="text" name="location" > <br>
		Seat Row: <input type="text" name="seat_row" > <br>
		Seat Column: <input type="text" name="seat_column" > <br>
		Operator: <input type="text" name="operator" > <br>
		Company: <input type="text" name="company" > <br>
		<input type="submit" name="submit" value="Submit" >
	</form>

	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo e($err); ?> <br>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH D:\ATP-03\DEMO\resources\views/manager/add_bus.blade.php ENDPATH**/ ?>