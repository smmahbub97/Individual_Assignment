<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Edit Tag</h1>&nbsp
	<a href="/system/admin/home">Back</a>||
	<a href="/logout">Logout</a> <br>

	<form method="post">
		<?php echo e(csrf_field()); ?>

		<table>
			<tr>
				<td>ID</td>
				<td><input type="text" readonly name="tagid" value="<?php echo e($tags->tagid); ?>"></td>
			</tr>
			<tr>
				<td>Tag</td>
				<td><input type="text" name="hashtag" value="<?php echo e($tags->hashtag); ?>"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="submit" value="Save"></td>
			</tr>
		</table>
	</form>
	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo e($err); ?> <br>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH C:\Users\Shishir\Downloads\atpASS\Individual_Assignment\resources\views/admin/edit_tag.blade.php ENDPATH**/ ?>