<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	
	<h1>Welcome Home</h1> |
	<a href="/system/buscounter">List of bus counter</a>| 
	<a href="/logout">Logout</a>
</body>
</html><?php /**PATH D:\ATP-03\DEMO\resources\views/manager/index.blade.php ENDPATH**/ ?>