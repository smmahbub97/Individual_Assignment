<!DOCTYPE html>
<html>
<head>
	
</head>
<body>	
	 | 
	<a href="/system/admin/home">Back</a>| 
	<a href="/logout">Logout</a>

	<table border="1">
		<tr>
			<th>Name</th>
			<th>Email</th>
			<th>Company</th>
			<th>Registered</th>
			<th>ACTION</th>
		</tr>
		
		<?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($manager->name); ?></td>
			<td><?php echo e($manager->email); ?></td>
			<td><?php echo e($manager->company); ?></td>
			<td><?php echo e($manager->registered); ?></td>
			<td>
				<a href="#">Edit</a> | 
				<a href="<?php echo e(route('admin.deletemanager',$manager->id)); ?>">Delete</a>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>

</body>
</html><?php /**PATH C:\Users\Shishir\Downloads\Individual_Assignment\resources\views/admin/view_list.blade.php ENDPATH**/ ?>