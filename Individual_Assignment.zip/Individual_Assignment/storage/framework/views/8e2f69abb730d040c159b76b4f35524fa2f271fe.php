<!DOCTYPE html>
<html>
<head>
	<title>Add Page</title>
</head>
<body>

	<h1>Add Tag</h1>&nbsp
	<a href="/system/admin/home">Back</a>
	<form method="post" >
		<?php echo csrf_field(); ?>
		Tag: <input type="text" name="hashtag" > <br>
		<input type="submit" name="submit" value="Submit" >
	</form>

	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo e($err); ?> <br>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH C:\Users\Shishir\Downloads\atpASS\Individual_Assignment\resources\views/admin/add.blade.php ENDPATH**/ ?>