<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	
	<h1>Welcome Home</h1> | 
	<a href="/system/supportstaff">List of All Staff</a>| 
	<a href="/system/busmanager">List of Bus Managers</a>| 
	<a href="/logout">Logout</a>
</body>
</html><?php /**PATH C:\Users\Shishir\Downloads\Individual_Assignment\resources\views/admin/index.blade.php ENDPATH**/ ?>