<!DOCTYPE html>
<html>
<head>
	<title>Delete Manager</title>
	<script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
</head>
<body>
<a href="<?php echo e(route('admin.deletemanager',$id)); ?>" data-method="delete">Delete</a>
</body>
<script>
$(document).ready(function(){
	if (confirm("Do you want to delete")) {
		
  	} 
    else {
    }
});
</script>
</html><?php /**PATH D:\ATP-03\DEMO\resources\views/admin/deletemanager.blade.php ENDPATH**/ ?>