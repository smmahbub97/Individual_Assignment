<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	
	<h1>Welcome Home, <?php echo e(session('email')); ?></h1> | 
	<a href="/logout">Logout</a>
</body>
</html><?php /**PATH C:\Users\Shishir\Downloads\atpASS\Individual_Assignment\resources\views/manager/index.blade.php ENDPATH**/ ?>