<!DOCTYPE html>
<html>
<head>
	<title>Edit Page</title>
</head>
<body>
	<form method="post" >
		<?php echo csrf_field(); ?>
		ID: <input type="text" disabled name="id" value=<?php echo e($bus->id); ?> > <br>
		Name: <input type="text" name="name" value=<?php echo e($bus->name); ?>> <br>
		Location: <input type="text" name="location"value=<?php echo e($bus->location); ?> > <br>
		Seat Row: <input type="text" name="seat_row" value=<?php echo e($bus->seat_row); ?>> <br>
		Seat Column: <input type="text" name="seat_column" value=<?php echo e($bus->seat_column); ?>> <br>
		Operator: <input type="text" name="operator" value=<?php echo e($bus->operator); ?>> <br>
		Company: <input type="text" name="company" value=<?php echo e($bus->company); ?>> <br>
		<input type="submit" name="submit" value="Submit" >
	</form>

	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo e($err); ?> <br>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH D:\ATP-03\DEMO\resources\views/manager/edit_bus.blade.php ENDPATH**/ ?>