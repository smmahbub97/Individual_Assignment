<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	
	<h1>Welcome Home, <?php echo e(session('email')); ?></h1> ||
	<a href="/system/category">Category List</a>||
	<a href="/system/tag">Tag List</a>||
	<a href="/logout">Logout</a>
</body>
</html><?php /**PATH C:\Users\Shishir\Downloads\atpASS\Individual_Assignment\resources\views/admin/index.blade.php ENDPATH**/ ?>